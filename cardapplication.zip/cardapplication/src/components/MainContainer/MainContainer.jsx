import React, {Fragment} from "react";
import { Container, BoldDiv } from "./MainContainer.style";
import {Flex,Box} from "@rebass/grid";
import {CardComponent} from "../CardComponent";
const MainContainer = props =>{
    return(
        
        <Fragment>
         <BoldDiv>Card Application
             </BoldDiv>   
            <Container>
            <CardComponent></CardComponent>
            </Container>
            
          
        </Fragment>
    );
}
export default MainContainer;