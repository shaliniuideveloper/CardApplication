import React, {Fragment} from "react";
//import {Flex,Box} from "@rebass/grid";
import tile from "../../img/tile.jpg"; 
import logo from "../../img/logo.png"; 
import {CardContainer,ImageBox,Box,Index,ImageContainer,Para} from "./CardComponent.style";
const CardComponent = props =>(
   
    
        
            <ImageContainer>
                <ImageBox style={{backgroundImage:"url(" + tile + ")"}}>
                   <Box style={{backgroundImage:"url(" + logo + ")"}}>
                        <Para>Home and Away</Para>
                    </Box> 
                </ImageBox>
            </ImageContainer>
            
            
         
            
            
          
            
            
        
        
                
           
                
           
       
       
    
);
export default CardComponent;