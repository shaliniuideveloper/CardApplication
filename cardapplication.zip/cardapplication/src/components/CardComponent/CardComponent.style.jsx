//import {Box} from '@rebass/grid';
import styled,{css} from "styled-components";
import tile from "../../img/tile.jpg";
const sizes = {
    desktop:992,
    tablet:768,
    phone:320,
    galaxy:360,
    iPhone:375,
    pixel:414,
    jumbo:1024,
}
const media = Object.keys(sizes).reduce((acc,label)=>{
    acc[label] = (...args) =>css`
    @media(max-width:${sizes[label]/16}em){
        ${css(...args)}
    }
    `
    return acc
},{})

export const CardContainer = styled.div`
position:absolute;

background:white;
width:315px;
height:195px;
/*Methods instead of raw queries*/
${media.desktop`background:white`}
${media.tablet`background:white`}
${media.phone`background:white;width:100%`}
`;

export const BoldDiv = styled.div`
color:cyan;
'font-weight':800;
`;
export const BodyDiv = styled.div`
color:white;
'padding-left':20px;
word-wrap:break-word;
`; 
export const Box = styled.div`
width:100%;
height:50px;
background:black;
position:absolute;
top:138px;
bottom:107px;
opacity: 0.5;
background-size: contain;
background-repeat:no-repeat ;





`;
export const Para = styled.p`
margin-top:7px;
margin-left:72px;
color:white;
font-weight:600;
font-size:20px;
`;
export const ImageBox = styled.div`
    position:absolute;
    width:100%
    height:auto;
    top:5px;
    bottom:18px;
    background:black;
    background-size: contain;
    background-repeat:no-repeat ;
    background-size:100%
    
    /*Methods instead of raw queries*/
    ${media.phone`bottom:-44px;background-size:100%`}
    ${media.galaxy`bottom:-66px;background-size:100%`}
    ${media.iPhone`bottom:-75px;background-size:100%`}
    ${media.pixel`bottom:-94px;background-size:100%`}
    ${media.tablet`bottom:-46px;background-size:100%`}
   
    

`;
export const ImageContainer = styled.div`
    
    position:absolute;
    top:5px;
    bottom:5px;
    left:5px;
    right:5px;
    background:white;
    /*Methods instead of raw queries*/
    /*Methods instead of raw queries*/
    ${media.desktop`width:100%;height:65%`}
    ${media.tablet`width:95%;height:65%`}
    ${media.phone`width:95%;height:65%`}    

`;

