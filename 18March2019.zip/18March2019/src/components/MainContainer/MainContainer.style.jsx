import {Flex,Box} from "@rebass/grid";
import styled from "styled-components";

export const Container = styled(Flex)`
align:center;
`;
